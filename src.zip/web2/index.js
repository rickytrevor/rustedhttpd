console.log("Funziona anche javascript e css!")

function updateTime() {
    const clock = document.querySelector("#clock")
    clock.innerText = new Date().toLocaleTimeString()

}


setInterval(updateTime, 1000)